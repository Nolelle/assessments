const rentalsRouter = require('./rentals')

module.exports = [rentalsRouter]
